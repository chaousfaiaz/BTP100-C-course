 /* Concepts
    1. complex data structure
    2. an array of C structures 

    updated on 9/01/2020
  */

 // the C struct type 
 struct Student {
     int no;
     char grade;
 };

 #define _CRT_SECURE_NO_WARNINGS
 #include <stdio.h>
 #define SIZE 3

 int main() {

     int k;
     
     /* an array of 3 structures with INITIALIZATION
	    Note: Watch out for [].
      */

     struct Student group[] = 
		       { { 10001, 'C' },  // group[0]
		         { 20002, 'B' },  // group[1]
		         { 30003, 'A' }   // group[2]
		       };
     
     /* an aray of 3 structures, not initialized */
     struct Student another_group[SIZE];

     /* Part 1. Display all the values from an array of three structures. */
     for (k=0; k < SIZE; k++) // k = k + 1;
	      printf( "%d. student number: %d, grade: %c\n",
		          (k+1), group[k].no, group[k].grade );

     /* Part 2. Change the values in an array of three structures. */
     printf( "*** Part 2 ***\n" );

     for (k=0; k < SIZE; k++){
	      group[k].grade += 1;  // increment the ASCII value of a character

	      printf( ">>>%d. student number: %7d, grade:%3c\n",
		          (k+1), group[k].no, group[k].grade );
     }

     /* Part 3. Copy an array of three structures. */
     printf ( "*** Part 3 ***\n" );

     // copy ALL the structures from one array to another array
     for (k=0; k<SIZE; ++k)
	      another_group[k] = group[k]; // copy a structure as a whole!

     for (k=0; k < SIZE; ++k)
	      printf( "[%d]: student number: %d, grade: %c\n",
		          (k+1), another_group[k].no, another_group[k].grade );

     return 0;
 }






			      
