 
 /* Question: Explain LINE BY LINE what this program does. You should start from the main program.
              For every step, write down a line number and the values of the variables.
			  e.g. 20: k is not initialized
			       22, 23, 24, 25: group is an array of 3 structures; group[0] has 10001, 'C';
				                  group[1] has 20002, 'B'; group[2] has 30003, 'A'.
								
  */

 struct Student {
     int no;
     char grade;
 };

 #define _CRT_SECURE_NO_WARNINGS
 #include <stdio.h>
 #define SIZE 3

 int main() {
     int k;                                 // line number: 20

     struct Student group[] =               // line number: 22
		     { { 10001, 'A' },              // line number: 23
		       { 20002, 'C' },              // line number: 24
		       { 30003, 'B' }               // line number: 25
		     };                             
   
     struct Student another_group[SIZE];    // line number: 28

     for (k=0; k < SIZE; k++)               // line number: 30
	      printf( "%d. student number:%6d, grade:%2c\n",     // line number: 31
		          (k+1), group[k].no, group[k].grade );      // line number: 32

    for (k=SIZE-1; k>=0; k--){               // line number: 34
	
	     group[k].grade += 1;               // line number: 36
		 
	     printf( ">>>%d. student number:%7d, grade:%3c\n",   // line number: 38
		         (k+1), group[k].no, group[k].grade );       // line number: 39
    }
	
    for (k=0; k<SIZE; ++k)                  // line number: 42
	     another_group[k] = group[k];       // line number: 43

    for (k=1; k<SIZE-1; ++k)                // line number: 45
	     printf( "[%d]: student number: %d, grade: %c\n",              // line number: 46
		         (k+1), another_group[k].no, another_group[k].grade ); // line number: 47

    return 0;
 }






			      
