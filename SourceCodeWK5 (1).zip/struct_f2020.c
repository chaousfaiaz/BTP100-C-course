/* Concepts
   1. data structure
   2. compound data type
      - a user-defined data type
      - a group of related variables (with various data types)
   3. C struct type
   4. the diagram of a C structure

   updated on 2/05/2021
 */

 #define _CRT_SECURE_NO_WARNINGS
 #include <stdio.h>

 /* declaration of a compound data type
    a user-defined type
    a struct TYPE  in C
  */
 struct Student {
     int no;          // no: data field; member
     char grade;      // grade: data field; member

 }; // semicolon!

 int main(){
     // three C struct variables(structures)

     struct Student x, 
		            y = { 2002, 'F' }, // initialization of a structure
		            z;

     /* Part 1 */
 
     // x: x.no, x.grade
     x.no = 1001;
     x.grade = 'A';

     // z: z.no, z.grade
     z.no = x.no + 90000;
     z.grade = x.grade + 2; // ASCII table

     printf( "x:: student no: %7d, grade: %c\n", x.no, x.grade );
     printf( "y:: student no: %7d, grade: %c\n", y.no, y.grade );
     printf( "z:: student no: %7d, grade: %c\n", z.no, z.grade );

     /* Part 2: Copying of a Structure */

     /* z.no = x.no; 
	    z.grade = x.grade; 
      */

     y = x;   // copy the values of a strucutre as a whole! 
     z = y;
     
     printf("\n");
     printf( "y:: student no: %7d, grade: %c\n", y.no, y.grade );
     printf( "z:: student no: %7d, grade: %c\n", z.no, z.grade );

     /* Part 3 */

     printf( "Please enter a student number (integer): " );
     scanf( "%d", &(x.no) );

     printf( "Please enter a letter grade: " );

     //getchar();   // remove the newline character from the buffer!
     scanf( "%c", &(x.grade) );  // scanf( "%*c%c", &(x.grade) );

     printf( "x:: student no: %7d, grade: %c\n", x.no, x.grade );    
     return 0;
 }

