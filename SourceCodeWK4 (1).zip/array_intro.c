/* Concepts
   1. a sequential data structure
   2. arrays 
   3. array name, array size, array index/position number, 
      data type of an array element
   4. use of a for loop
   5. array subscript (a[k])
  
   updated on 8/31/2020
 */ 

 #include <stdio.h>

 const int  MAX=6; // a constant variable

 int main (void) {

     int k,
	 sum=0,
	 marks[6] = { 11, 22, 33, 44, 55, 66 };  /* declaration of an array */
						 /* int marks[6]; */

     double average;

     /* Part 1A. Print all values from an array. */ 
     
     for (k=0; k < MAX; k++){  // < MAX, not <= MAX!

	  printf( "%5d", marks[k] );   // the width of a field: 7
     }

     /* Part 1B. Print all values from an array in reverse */

     printf( "\n...Print all the values in reverse:\n" );

     for (k=5; k >= 0; k--) { // k > 0? k > -1? k == 0? k != 0?

	  printf( "%5d", marks[k] );
     }

     /* Part 2. Add all the values in an array and calculate the average. */
     
     for (k=0; k < MAX; k++){ 

	  sum += marks[k]; // sum = sum + marks[k];
     }

     average = (double)sum / MAX ; // what kind of division?
								   \
     
     printf( "\n\nsum: %d, average: %12.2lf\n\n", 
	     sum, average);

     /* Part 3. Change some values in an array. */

     marks[0] = -123;
     marks[3] = -567;

     // Print the values of an array in reverse.
     for (k=MAX-1; k >= 0; k--)   /* >= 0, not > 0 */

	  printf( "k:%d, %05d\n", k, marks[k] ); // leading zeroes
     
     printf("\n" );

     /* Part 4. Ask the user for integers to populate an array. */

     sum = 0;

     for (k=0; k < MAX; k++) {     

	  printf( "Please enter an integer score: " );
	  scanf( "%d", &marks[k] );  /* & + marks[k] */
	  sum += marks[k];
     }

     printf( "total scores: %d, average score: %.2lf\n",
	      sum, ((double) sum)/ MAX );

     /* Debugging Question: What will happen?

	printf( "2. Problems??? >>> %d, %d\n", marks[-1], marks[5] );
      */

     return 0;
 }




























