/* Concepts
   1. processing of tabular data
   2. parallel arrays 

   updated on 8/31/2020
 */

 #include <stdio.h>
 #define MAX_ITEMS 5

 void show();

 int main (void) {

     /* declarations of three parallel arrays */

     int    qty[MAX_ITEMS], i;

     double price[MAX_ITEMS] = { 0.5, 1.25, 3.99, 2.75, 1.15 },
	    total[MAX_ITEMS];

     show();

     for ( i=1; i <= MAX_ITEMS; i++ ) {

	  printf( "How many units do you want for item #%d? ", i );

	  scanf( "%d", &qty[ i-1 ] );
     }

     /* calculate the total amount of purchase for each item */

     for (i=0; i < MAX_ITEMS; i++)

	  total[i] = qty[i] * price[i];

     printf( "\n\nPRICE    QTY             TOTAL\n" );

     for (i=0; i<MAX_ITEMS; i++)

	  printf( "$%.2lf%7d%10c$%8.2lf\n", 
		  price[i], qty[i], ' ', total[i] );

     return 0;
 }

 void show( ) {

    printf( "Item Descriptions\n" );
    printf( "1. pencil  2. binder  3. whiteboard  4. scissors  5. stickers\n" );
 }














