/* do-while loop
    - number of iterations: at least once
   flowchart

   infinite loop!
    - user input: 'A'
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define PASSWORD 54321
// const int PASSWORD=54321;

int main(void) {

   int password;

   do{
      printf( "Please enter your password (an integer):\n" );
      scanf( "%d", &password );

   }while ( password != PASSWORD );

   printf( "You have entered the correct password!\n" );
   return 0;
}
