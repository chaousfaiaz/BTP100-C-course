
/* 1. Concepts
      a) the OR logical operator: ||
      b) the truth table
      c) testing
	  d) De Morgan's Law:
	     https://ict.senecacollege.ca/~btp100/pages/content/expre.html#log
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define STOCK_LEVEL 7

int main(void) {

   int number, sold;    /* variable declarations */

   number = STOCK_LEVEL;
   sold = 0;

   printf( "Welcome!!!\nWe have %d apples in the store.\n", number );
   printf( "How many apples do you want? " );

   scanf( "%d", &sold  );

   /* Check if the user input value is out of range (2 cases) */

   if ( ( sold < 0 ) || ( sold > number ) ) {  // the OR operator: 2 invalid conditions

	    if (sold < 0)
		    printf( "+++ Error #1: The integer cannot be negative!\n" );

	    if (sold > number) {
		    printf( "+++ YOU WANT TO BUY %d APPLES.\n", sold );
		    printf( "+++ SORRY! OUR STORE CANNOT SELL YOU SO MANY APPLES.\n" );
	    }
   }
   else { /* within the range of valid values  */

	      printf( "You want to buy %d apples.\n", sold );
	      number = number - sold;

   } /* end else */

   printf( "\n*** The store has %d apples left. Please come back ***\n", number );
}
