/* 1. Concepts
      a) the AND logical operator: &&
      b) the truth table
      c) testing
	 - sold < 0
	 - sold <= number
	 - sold > number
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define STOCK_LEVEL 7

int main(void) {

   /* variable declarations 
      - number: number of apples in the store
	  - sold: number of apples one wants to buy
	*/
   int number, sold;    
                        
   number = STOCK_LEVEL;
   sold = 0;

   printf( "We have %d apples in the store.\n", number );
   printf( "How many apples do you want to buy? " );

   scanf( "%d", &sold  );

   /* Check if the user input value is within a valid range 
      (between 0 and 7, inclusive)
   */
   if ( (0 <= sold) && (sold <= number) ) { 

	     number = number - sold;  // update the number of apples in the store
   }
   else { // the user input value is out of the range (2 cases)

	      if (sold < 0)
		      printf( "--- Error #1: The integer cannot be negative! ---\n" );

	      if (sold > number)
		      printf( "--- Error #2: The integer is out of range! ---\n" );

	      /* A BETTER DESIGN: if-then-else logic */
   } // end else

   /* print a summary */
   if (sold >=0)
       printf( "You want to buy %d apples.\n", sold);

   printf( "*** The store has %d apples left. ***\n", number );

   return 0;
}
