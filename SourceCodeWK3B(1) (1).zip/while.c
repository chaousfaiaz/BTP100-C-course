
/* Concepts
    1. indefinite iteration
       - total number of iterations: unknown (i.e. not fixed)
    2. a while loop
    3. flowchart (Course Notes)
    4. an infinite loop!
       - user input: 'A', -3.45

	5. De Morgan's Law (Course Notes)
    updated on 1/22/2021
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {

    int apples= -224466; //2111;
    
    printf( "How many apples do you want to buy? " );
    scanf( "%d", &apples );
    
    while (apples < 0) {  // a boolean test
			                
	   /* the body of a while loop */
       printf( "###ERROR: You have entered a negative number!\n" ); 
	   
       printf( "How many apples do you want to buy? " );
       scanf( "%d", &apples );   // change
    }

    printf( "Thank you! You want to buy %d apples.\n\n", apples );

	/* Part 2 */
	printf("... number of apples (0-7):> ");
	scanf("%d", &apples);

	while ( !((0<=apples) && (apples<=7)) ){ // a boolean test: NOT within range
		                                     // use De Morgan's Law to simplify the code!

	   /* the body of a while loop */
		printf("###ERROR: Your number is OUT OF RANGE!\n");

		printf("... number of apples:> ");
		scanf("%d", &apples);   // change
	}

    return 0;
}




