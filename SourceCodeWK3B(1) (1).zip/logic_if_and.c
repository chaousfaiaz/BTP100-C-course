#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/* Concepts
   1. selection/decision logic
      a) if-then
      b) if-then-else 
      c) https://ict.senecacollege.ca/~btp100/pages/content/const.html#sel

   2. relational operators: ==, !=, <, <=, >, >=
   3. logical operators: &&, ||
 */

/* 5 test cases
   - negative integer (out of range)!
   - 0 (boundary condition)
   - 5
   - 7 (boundary condition)
   - 12 (out of range)!

   updated on 08/28/2020
 */


int main() {

   int number, sold=0;    /* variable declarations 
			     - number: number of apples in the store
			     - sold: number of apples that a customer wants to buy
			   */

   number = 7;

   printf( "We have %d apples in the store.\n", number );

   printf( "How many apples do you want to buy?\n" );

   scanf( "%d", &sold  );

   /* Case #1: The user has entered a negative integer. */
   if ( sold < 0 ){   // relational expression

	printf( "--- Error #1: The number cannot be negative! ---\n" );
   }
   

   /* Case #2: The user has entered an integer that is greater than 7. */
   if ( sold > 7 ){

	printf( "--- Error #2: The number is greater than 7! ---\n" );
   }   

   /* Case #3: The user has entered an integer that is between 0 and 7 (inclusive) */
   if (0 <= sold){ 

      if (sold <= 7){ // nested decision logic

	   printf( "You want to buy %d apples.\n", sold );
	   number = number - sold;

	   printf( "The store has %d apples left.\n", number );
      }
   }

   /* alternative solution: if ( 0<=sold && sold<=7) */

   /* Note: The first two logical tests are mutually exclusive! */

   return 0;
}
