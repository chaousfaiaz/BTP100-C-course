#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/* concepts
   1. selection/decision logic
      a) if-then-else
      b) https://ict.senecacollege.ca/~btp100/pages/content/const.html#sel 
   2. nested if-then-else  
   3. testing
      a) 5 test cases (logic_if_and.c)

   updated on 8/28/2020 
 */

const int QTY_IN_STOCK = 7;  // an integer constant

int main() {

   int number, sold=0;    /* variable declarations 
			   - number: number of apples in the store
			   - sold: number of apples that a customer wants to buy
			 */

   number = QTY_IN_STOCK;

   printf( "Welocme! We have %d apple(s) in the store.\n", number );

   printf( "How many apples do you want? " );

   scanf( "%d", &sold  );

   // 1. Check if the user input is within the range or out of the range

   if ( sold < 0 ){

	printf( "--- ERROR #1: The number cannot be negative! ---\n" );
   }
   else{ // sold >= 0: sold > 7? sold <= 7?
          // nested decision logic

	 if ( sold > QTY_IN_STOCK ) // '{' is missing!

	      printf ( "--- ERROR #2: The number cannot be greater than %d! ---\n",
		           QTY_IN_STOCK );
	
	 else{
	       printf( "You want to buy %d apple(s).\n", sold );

	       number = number - sold;

	       printf( "The store has %d apple(s) left.\n", number );
	 }
   }

   printf( "Thank you! Please come back again!!!\n" );
}
