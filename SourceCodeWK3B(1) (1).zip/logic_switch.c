
/* 1. Concepts
      a) case-by-case analysis logic
	 - chaining of if-then-else logic
      b) a switch statement 
	 - break
	 - the default case
      c) testing
   
      updated on 8/28/2020
 */

#include <stdio.h>

int main(void) {

   double readingC = -9999;

   int advice=0;

   printf( "Please enter a temperature reading in Celsius: " );

   scanf( "%lf" , &readingC );

   /* Part 1: case by case analysis (temperature reading) */

   if (readingC >= 35.0) {

       advice = 1;
   }
   else if ( (readingC >= 20) &&  (readingC < 35) ) {

	      advice = 2;
	}
	else if ( (0 <= readingC) && (readingC < 20) ) {

		  advice = 3;
	     }
	     else
		  advice = 4;

   //advice = 1000;

   /* Part 2: use of a switch statement (advice level)
      - possible values of advice: 1, 2, 3, 4,... */

   switch (advice){
      case 1: printf( "The weather is too hot to travel.\n" );
	      break;

      case 2: printf( "The weather is warm. Travel at your own leisure.\n" );
	      break;

      case 3: printf( "The weather is chilly. Bring more clothes when you travel.\n" );
	      break;

      case 4: printf( "The weather is too cold to travel.\n" );
	      break;

      default: printf( "Travel at your own risk!\n" );
   }

   return 0;
}






































void printAdvice( double tc ) {

	int    cold=0, warm=0, hot=0;  /* use of flags */

	if ( tc >= 35.0 ) {

	      printf( "The weather is hot!\n" );

	      hot = 1;
	   }

	if ( ( tc >= 20 ) &&  ( tc < 35 ) ) {

	      printf( "The weather is warm.\n" );

	      warm = 1;
	   }

	if ( tc < 20 ) {

	      printf( "The weather is cold....\n" );

	      cold = 1;
	   }

	if ( cold == 1 || hot == 1 )

		 printf( "Advice: Do NOT travel! The weather is not good.\n" );

	else printf( "Advice: Have a nice trip!\n" );

}








