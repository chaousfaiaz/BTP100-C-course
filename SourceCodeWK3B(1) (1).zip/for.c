/* Concepts
   1. for loop
       - counter-controlled iteration
       - fixed iteration
          - number of iterations (controlled by a counter)
       - flowchart
   2. infinite loop?
       - user input: 'A'
   3. flags (Course Notes, video clip)

   updated on 1/22/2021
 */

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {

   int num,  i, sum=0, flag=0;   // 0: false

   for (i=1; i<=4; i=i+1) { // shortcut: for (i=1; i<=4; i++)

      printf( "Please enter an integer: " );
      scanf( "%d", &num );

      sum = sum + num;

      printf( "...sum: %d\n", sum );

   } // end of the for loop

   printf( ">>> after exiting the for loop: i:%d, sum:%d\n", i, sum );
   printf( "\nDONE!\n" );

   /* Part 2: use of a flag (Course Notes) */
   sum = 0;
   for (i = 1; (i<=4)&&(flag==0); i++) {   // 0: true

	   printf("Enter an integer:> ");
	   scanf("%d", &num);

	   sum = sum + num;
	   printf("[%d] sum: %d\n", i, sum);

	   if (sum >= 100)
		   flag = 1; // 1: true
   }
   
   printf("\n... You have entered %d integrs.\n", i-1);  // i? i-1?
   return 0;

}
